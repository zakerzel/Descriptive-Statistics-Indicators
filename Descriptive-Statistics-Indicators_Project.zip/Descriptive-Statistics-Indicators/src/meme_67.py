"""Optional easter egg for the '67' meme."""


class Meme67Detector:
    def __init__(self, enabled: bool = True, window_seconds: float = 4.0):
        self.enabled = enabled
        self.window_seconds = window_seconds
        self.last_five_time = None
        self.last_trigger_time = None

    def reset(self):
        self.last_five_time = None
        self.last_trigger_time = None

    def update(self, finger_count: int, gesture: str, timestamp: float):
        if not self.enabled:
            return
        if finger_count == 5 or gesture == "open_palm":
            self.last_five_time = timestamp
        if finger_count == 2 or gesture == "peace":
            if self.last_five_time and (timestamp - self.last_five_time <= self.window_seconds):
                self.last_trigger_time = timestamp

    def get_message(self):
        if not self.enabled or self.last_trigger_time is None:
            return ""
        return "67 detected! symbolic meme mode"
