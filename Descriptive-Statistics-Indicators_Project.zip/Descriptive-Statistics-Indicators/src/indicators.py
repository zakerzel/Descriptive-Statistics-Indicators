"""Statistical indicators for the live dashboard."""

import pandas as pd


def _safe_percentage(numerator, denominator):
    if denominator == 0:
        return 0.0
    return round((numerator / denominator) * 100, 2)


def compute_indicators(df: pd.DataFrame) -> dict:
    if df is None or df.empty:
        return {
            "total_detections": 0,
            "unique_people": 0,
            "most_common_gesture": "-",
            "most_common_finger_count": "-",
            "thumbs_up_rate": 0.0,
            "left_hand_rate": 0.0,
            "right_hand_rate": 0.0,
            "returning_people": 0,
            "detections_by_person": {},
            "gesture_distribution": {},
            "trend_by_minute": {},
        }

    df = df.copy()
    total = len(df)
    unique_people = int(df["person_id"].nunique()) if "person_id" in df else 0

    most_common_gesture = "-"
    if "gesture" in df and not df["gesture"].dropna().empty:
        most_common_gesture = str(df["gesture"].mode().iloc[0])

    most_common_finger_count = "-"
    if "finger_count" in df and not df["finger_count"].dropna().empty:
        most_common_finger_count = int(df["finger_count"].mode().iloc[0])

    thumbs_up_count = int((df["gesture"] == "thumbs_up").sum()) if "gesture" in df else 0
    thumbs_up_rate = _safe_percentage(thumbs_up_count, total)

    left_count = int((df["hand"] == "Left").sum()) if "hand" in df else 0
    right_count = int((df["hand"] == "Right").sum()) if "hand" in df else 0

    detections_by_person = {}
    returning_people = 0
    if "person_id" in df:
        detections_by_person = df["person_id"].value_counts().to_dict()
        returning_people = int(sum(1 for count in detections_by_person.values() if count > 1))

    gesture_distribution = df["gesture"].value_counts().head(8).to_dict() if "gesture" in df else {}

    trend_by_minute = {}
    if "timestamp" in df:
        timestamps = pd.to_datetime(df["timestamp"], errors="coerce")
        valid = df[timestamps.notna()].copy()
        valid["minute"] = timestamps[timestamps.notna()].dt.strftime("%H:%M")
        trend_by_minute = valid["minute"].value_counts().sort_index().tail(8).to_dict()

    return {
        "total_detections": total,
        "unique_people": unique_people,
        "most_common_gesture": most_common_gesture,
        "most_common_finger_count": most_common_finger_count,
        "thumbs_up_rate": thumbs_up_rate,
        "left_hand_rate": _safe_percentage(left_count, total),
        "right_hand_rate": _safe_percentage(right_count, total),
        "returning_people": returning_people,
        "detections_by_person": detections_by_person,
        "gesture_distribution": gesture_distribution,
        "trend_by_minute": trend_by_minute,
    }
