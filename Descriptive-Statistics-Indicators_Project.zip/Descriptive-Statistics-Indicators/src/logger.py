"""CSV logging utilities."""

from datetime import datetime
from pathlib import Path
import pandas as pd


class GestureLogger:
    def __init__(self, csv_path: Path):
        self.csv_path = Path(csv_path)
        self.columns = ["timestamp", "person_id", "hand", "finger_count", "gesture", "confidence"]
        if not self.csv_path.exists():
            self.reset()

    def reset(self):
        pd.DataFrame(columns=self.columns).to_csv(self.csv_path, index=False)

    def log_detection(self, person_id: str, hand: str, finger_count: int, gesture: str, confidence: float):
        row = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "person_id": person_id,
            "hand": hand,
            "finger_count": finger_count,
            "gesture": gesture,
            "confidence": round(float(confidence), 4),
        }
        pd.DataFrame([row]).to_csv(self.csv_path, mode="a", header=False, index=False)
