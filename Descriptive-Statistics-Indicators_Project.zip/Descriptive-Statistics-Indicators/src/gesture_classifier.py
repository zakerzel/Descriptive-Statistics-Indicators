"""
Gesture classification based on MediaPipe hand landmarks.
The classifier is intentionally simple and explainable for a class demo.
"""

FINGER_TIPS = {"thumb": 4, "index": 8, "middle": 12, "ring": 16, "pinky": 20}
FINGER_PIPS = {"index": 6, "middle": 10, "ring": 14, "pinky": 18}


def _is_thumb_extended(landmarks, hand_label: str) -> bool:
    thumb_tip = landmarks[FINGER_TIPS["thumb"]]
    thumb_ip = landmarks[3]

    if hand_label.lower() == "right":
        return thumb_tip.x < thumb_ip.x
    return thumb_tip.x > thumb_ip.x


def get_finger_states(landmarks, hand_label: str) -> dict:
    states = {"thumb": _is_thumb_extended(landmarks, hand_label)}
    for finger, tip_idx in FINGER_TIPS.items():
        if finger == "thumb":
            continue
        pip_idx = FINGER_PIPS[finger]
        states[finger] = landmarks[tip_idx].y < landmarks[pip_idx].y
    return states


def count_extended_fingers(finger_states: dict) -> int:
    return int(sum(1 for value in finger_states.values() if value))


def classify_gesture(finger_states: dict) -> str:
    count = count_extended_fingers(finger_states)
    thumb = finger_states.get("thumb", False)
    index = finger_states.get("index", False)
    middle = finger_states.get("middle", False)
    ring = finger_states.get("ring", False)
    pinky = finger_states.get("pinky", False)

    if count == 0:
        return "fist"
    if count == 5:
        return "open_palm"
    if count == 1 and thumb:
        return "thumbs_up"
    if count == 1 and index:
        return "one_finger"
    if count == 2 and index and middle:
        return "peace"
    if count == 3 and index and middle and ring:
        return "three_fingers"
    if count == 4 and index and middle and ring and pinky:
        return "four_fingers"
    return f"{count}_fingers"
