"""
Anonymous visual person re-identification.

This module does not perform biometric identification. It only assigns temporary
anonymous labels such as Person 1 or Person 2 based on general visual appearance
patterns during the classroom session.
"""

from dataclasses import dataclass
import cv2
import mediapipe as mp
import numpy as np


@dataclass
class PersonResult:
    person_id: str | None
    bbox: tuple[int, int, int, int] | None
    similarity: float


class AnonymousPersonReID:
    def __init__(self, similarity_threshold: float = 0.58):
        self.similarity_threshold = similarity_threshold
        self.profiles: dict[str, np.ndarray] = {}
        self.next_person_number = 1
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(
            static_image_mode=False,
            model_complexity=1,
            enable_segmentation=False,
            min_detection_confidence=0.55,
            min_tracking_confidence=0.50,
        )

    def reset_profiles(self):
        self.profiles = {}
        self.next_person_number = 1

    def identify(self, frame_bgr) -> PersonResult:
        bbox = self._detect_person_bbox(frame_bgr)
        if bbox is None:
            return PersonResult(None, None, 0.0)

        crop = self._safe_crop(frame_bgr, bbox)
        if crop is None or crop.size == 0:
            return PersonResult(None, bbox, 0.0)

        hist = self._extract_histogram(crop)

        if not self.profiles:
            person_id = self._create_new_profile(hist)
            return PersonResult(person_id, bbox, 1.0)

        best_id, best_similarity = self._find_best_match(hist)
        if best_similarity >= self.similarity_threshold:
            self._update_profile(best_id, hist)
            return PersonResult(best_id, bbox, best_similarity)

        person_id = self._create_new_profile(hist)
        return PersonResult(person_id, bbox, best_similarity)

    def _detect_person_bbox(self, frame_bgr):
        h, w = frame_bgr.shape[:2]
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        results = self.pose.process(rgb)

        if not results.pose_landmarks:
            return None

        xs, ys = [], []
        for lm in results.pose_landmarks.landmark:
            if lm.visibility >= 0.45:
                xs.append(lm.x)
                ys.append(lm.y)

        if not xs or not ys:
            return None

        x1 = int(max(0, min(xs) * w - 40))
        y1 = int(max(0, min(ys) * h - 60))
        x2 = int(min(w, max(xs) * w + 40))
        y2 = int(min(h, max(ys) * h + 60))

        if x2 - x1 < 60 or y2 - y1 < 80:
            return None
        return x1, y1, x2, y2

    def _safe_crop(self, frame_bgr, bbox):
        x1, y1, x2, y2 = bbox
        return frame_bgr[y1:y2, x1:x2]

    def _extract_histogram(self, crop_bgr):
        crop_resized = cv2.resize(crop_bgr, (160, 220))
        hsv = cv2.cvtColor(crop_resized, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1, 2], None, [12, 8, 8], [0, 180, 0, 256, 0, 256])
        cv2.normalize(hist, hist)
        return hist.flatten().astype("float32")

    def _find_best_match(self, hist):
        best_id = None
        best_similarity = -1.0
        for person_id, profile_hist in self.profiles.items():
            similarity = float(cv2.compareHist(profile_hist.astype("float32"), hist.astype("float32"), cv2.HISTCMP_CORREL))
            if similarity > best_similarity:
                best_similarity = similarity
                best_id = person_id
        return best_id, best_similarity

    def _create_new_profile(self, hist):
        person_id = f"Person {self.next_person_number}"
        self.profiles[person_id] = hist
        self.next_person_number += 1
        return person_id

    def _update_profile(self, person_id, hist):
        previous = self.profiles[person_id]
        updated = (0.85 * previous) + (0.15 * hist)
        cv2.normalize(updated, updated)
        self.profiles[person_id] = updated.astype("float32")
