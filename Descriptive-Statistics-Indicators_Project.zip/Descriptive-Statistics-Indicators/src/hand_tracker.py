"""MediaPipe Hands wrapper for finger counting and gesture detection."""

import cv2
import mediapipe as mp

from src.gesture_classifier import get_finger_states, count_extended_fingers, classify_gesture


class HandTracker:
    def __init__(self, max_num_hands: int = 2):
        self.mp_hands = mp.solutions.hands
        self.mp_drawing = mp.solutions.drawing_utils
        self.mp_styles = mp.solutions.drawing_styles
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=max_num_hands,
            model_complexity=1,
            min_detection_confidence=0.60,
            min_tracking_confidence=0.55,
        )

    def process(self, frame_bgr):
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb)
        output = []

        if not results.multi_hand_landmarks:
            return output

        handedness_list = results.multi_handedness or []

        for idx, hand_landmarks in enumerate(results.multi_hand_landmarks):
            hand_label = "Unknown"
            confidence = 0.0
            if idx < len(handedness_list):
                hand_info = handedness_list[idx].classification[0]
                hand_label = hand_info.label
                confidence = float(hand_info.score)

            landmarks = hand_landmarks.landmark
            finger_states = get_finger_states(landmarks, hand_label)
            finger_count = count_extended_fingers(finger_states)
            gesture = classify_gesture(finger_states)

            output.append({
                "hand_landmarks": hand_landmarks,
                "hand_label": hand_label,
                "confidence": confidence,
                "finger_states": finger_states,
                "finger_count": finger_count,
                "gesture": gesture,
            })
        return output

    def draw(self, frame_bgr, hand_result):
        hand_landmarks = hand_result["hand_landmarks"]
        self.mp_drawing.draw_landmarks(
            frame_bgr,
            hand_landmarks,
            self.mp_hands.HAND_CONNECTIONS,
            self.mp_styles.get_default_hand_landmarks_style(),
            self.mp_styles.get_default_hand_connections_style(),
        )

        h, w = frame_bgr.shape[:2]
        xs = [lm.x for lm in hand_landmarks.landmark]
        ys = [lm.y for lm in hand_landmarks.landmark]
        x1 = int(max(0, min(xs) * w))
        y1 = int(max(0, min(ys) * h))
        x2 = int(min(w, max(xs) * w))
        y2 = int(min(h, max(ys) * h))

        label = f"{hand_result['hand_label']} | {hand_result['gesture']} | {hand_result['finger_count']}"
        cv2.rectangle(frame_bgr, (x1, y1), (x2, y2), (0, 255, 120), 2)
        cv2.putText(frame_bgr, label, (x1, max(25, y1 - 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 255, 120), 2)

    def close(self):
        self.hands.close()
