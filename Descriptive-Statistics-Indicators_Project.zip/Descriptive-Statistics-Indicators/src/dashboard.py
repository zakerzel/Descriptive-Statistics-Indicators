"""OpenCV dashboard panel drawing."""

import cv2
import numpy as np


def _put_text(panel, text, x, y, scale=0.52, color=(255, 255, 255), thickness=1):
    cv2.putText(panel, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness, cv2.LINE_AA)


def _draw_bar(panel, label, value, max_value, x, y, width=220, height=14):
    max_value = max(max_value, 1)
    ratio = min(float(value) / max_value, 1.0)
    cv2.rectangle(panel, (x, y), (x + width, y + height), (65, 65, 65), -1)
    cv2.rectangle(panel, (x, y), (x + int(width * ratio), y + height), (0, 180, 255), -1)
    _put_text(panel, f"{label}: {value}", x, y - 4, scale=0.42, color=(240, 240, 240))


def draw_dashboard_panel(indicators: dict, height: int = 720, width: int = 430):
    panel = np.zeros((height, width, 3), dtype=np.uint8)
    panel[:] = (32, 32, 32)

    y = 32
    _put_text(panel, "REAL-TIME INDICATORS", 20, y, scale=0.75, color=(0, 255, 255), thickness=2)

    y += 38
    _put_text(panel, f"Total detections: {indicators['total_detections']}", 20, y)
    y += 28
    _put_text(panel, f"Unique people: {indicators['unique_people']}", 20, y)
    y += 28
    _put_text(panel, f"Returning people: {indicators['returning_people']}", 20, y)

    y += 38
    _put_text(panel, "Central tendency", 20, y, scale=0.60, color=(80, 220, 255), thickness=2)
    y += 28
    _put_text(panel, f"Most common gesture: {indicators['most_common_gesture']}", 20, y)
    y += 26
    _put_text(panel, f"Most common fingers: {indicators['most_common_finger_count']}", 20, y)

    y += 38
    _put_text(panel, "Rates / proportions", 20, y, scale=0.60, color=(80, 220, 255), thickness=2)
    y += 28
    _put_text(panel, f"Thumbs-up rate: {indicators['thumbs_up_rate']}%", 20, y)
    y += 26
    _put_text(panel, f"Left hand rate: {indicators['left_hand_rate']}%", 20, y)
    y += 26
    _put_text(panel, f"Right hand rate: {indicators['right_hand_rate']}%", 20, y)

    y += 40
    _put_text(panel, "Comparison by person", 20, y, scale=0.60, color=(80, 220, 255), thickness=2)
    y += 35
    detections = indicators.get("detections_by_person", {})
    max_person_count = max(detections.values(), default=1)
    for person_id, count in list(detections.items())[:6]:
        _draw_bar(panel, person_id, count, max_person_count, 20, y, width=260)
        y += 34

    y += 12
    _put_text(panel, "Gesture distribution", 20, y, scale=0.60, color=(80, 220, 255), thickness=2)
    y += 35
    gestures = indicators.get("gesture_distribution", {})
    max_gesture_count = max(gestures.values(), default=1)
    for gesture, count in list(gestures.items())[:6]:
        _draw_bar(panel, gesture, count, max_gesture_count, 20, y, width=260)
        y += 34

    _put_text(panel, "q: quit | s: screenshot | r: reset | m: 67 mode", 20, height - 20, scale=0.43, color=(180, 180, 180))
    return panel
