"""
Classwork #08 — Live Gesture Recognition + Statistical Indicators Dashboard

Run:
    python app.py
"""

import time
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

from src.hand_tracker import HandTracker
from src.person_reid import AnonymousPersonReID
from src.logger import GestureLogger
from src.indicators import compute_indicators
from src.dashboard import draw_dashboard_panel
from src.meme_67 import Meme67Detector


DATA_DIR = Path("data")
SCREENSHOT_DIR = Path("screenshots")
LOG_PATH = DATA_DIR / "gesture_log.csv"

DATA_DIR.mkdir(exist_ok=True)
SCREENSHOT_DIR.mkdir(exist_ok=True)


def draw_status_bar(frame, person_id, hand_label, finger_count, gesture, meme_message, fps):
    h, w = frame.shape[:2]
    cv2.rectangle(frame, (0, 0), (w, 95), (20, 20, 20), -1)
    cv2.putText(frame, "Classwork #08 - Gesture Recognition + Indicators", (15, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2)

    line = f"Person: {person_id or 'Detecting...'} | Hand: {hand_label or '-'} | Fingers: {finger_count if finger_count is not None else '-'} | Gesture: {gesture or '-'} | FPS: {fps:.1f}"
    cv2.putText(frame, line, (15, 62), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (0, 255, 255), 2)

    if meme_message:
        cv2.putText(frame, meme_message, (15, 88), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 180, 255), 2)


def reset_log_and_profiles(logger, person_reid):
    logger.reset()
    person_reid.reset_profiles()


def main():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        raise RuntimeError("Could not open webcam. Check camera permissions or change the camera index.")

    hand_tracker = HandTracker(max_num_hands=2)
    person_reid = AnonymousPersonReID(similarity_threshold=0.58)
    logger = GestureLogger(LOG_PATH)
    meme67 = Meme67Detector(enabled=True)

    last_log_time = 0.0
    log_interval_seconds = 0.80
    frame_counter = 0
    fps = 0.0
    fps_time = time.time()

    print("System running.")
    print("Controls: q=quit | s=screenshot | r=reset log/profiles | m=toggle 67 meme mode")

    while True:
        ok, frame = cap.read()
        if not ok:
            print("Could not read frame from webcam.")
            break

        frame_counter += 1
        now = time.time()
        if now - fps_time >= 1.0:
            fps = frame_counter / (now - fps_time)
            frame_counter = 0
            fps_time = now

        frame = cv2.flip(frame, 1)

        person_result = person_reid.identify(frame)
        person_id = person_result.person_id
        person_box = person_result.bbox

        if person_box:
            x1, y1, x2, y2 = person_box
            cv2.rectangle(frame, (x1, y1), (x2, y2), (80, 200, 255), 2)
            cv2.putText(frame, person_id, (x1, max(25, y1 - 10)), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (80, 200, 255), 2)

        hand_results = hand_tracker.process(frame)

        active_hand_label = None
        active_finger_count = None
        active_gesture = None
        active_confidence = 0.0

        for hand in hand_results:
            active_hand_label = hand["hand_label"]
            active_finger_count = hand["finger_count"]
            active_gesture = hand["gesture"]
            active_confidence = hand["confidence"]
            hand_tracker.draw(frame, hand)

            if now - last_log_time >= log_interval_seconds and person_id:
                logger.log_detection(
                    person_id=person_id,
                    hand=active_hand_label,
                    finger_count=active_finger_count,
                    gesture=active_gesture,
                    confidence=active_confidence,
                )
                meme67.update(active_finger_count, active_gesture, now)
                last_log_time = now

        meme_message = meme67.get_message()

        if LOG_PATH.exists():
            try:
                df = pd.read_csv(LOG_PATH)
            except Exception:
                df = pd.DataFrame()
        else:
            df = pd.DataFrame()

        indicators = compute_indicators(df)

        draw_status_bar(frame, person_id, active_hand_label, active_finger_count, active_gesture, meme_message, fps)
        dashboard = draw_dashboard_panel(indicators, height=frame.shape[0], width=430)
        combined = np.hstack([frame, dashboard])

        cv2.imshow("Classwork #08 - Live Gesture Recognition Dashboard", combined)
        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break
        if key == ord("s"):
            shot_path = SCREENSHOT_DIR / f"screenshot_{int(time.time())}.png"
            cv2.imwrite(str(shot_path), combined)
            print(f"Screenshot saved: {shot_path}")
        if key == ord("r"):
            reset_log_and_profiles(logger, person_reid)
            meme67.reset()
            print("Log and anonymous person profiles were reset.")
        if key == ord("m"):
            meme67.enabled = not meme67.enabled
            print(f"67 meme mode enabled: {meme67.enabled}")

    cap.release()
    cv2.destroyAllWindows()
    hand_tracker.close()


if __name__ == "__main__":
    main()
