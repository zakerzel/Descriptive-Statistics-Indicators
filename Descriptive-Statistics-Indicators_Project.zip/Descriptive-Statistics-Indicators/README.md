# Classwork #08 — Live Gesture Recognition + Statistical Indicators Dashboard

**Course:** Visualization Tools  
**Team:** Gael, Alberto, Yazira, Fabio  
**Project:** Descriptive Statistics & Indicators

This project implements a local webcam-based system for Classwork #08.

## What the system does

The system detects:

- Number of extended fingers from 0 to 5.
- Basic gestures such as `fist`, `open_palm`, `thumbs_up`, `peace`, `three_fingers`, `four_fingers`.
- Left hand vs. right hand.
- Anonymous people automatically as `Person 1`, `Person 2`, etc.
- Re-appearance of a previously detected person using anonymous visual appearance re-identification.
- Statistical indicators in real time.
- Optional `67 meme mode` using a symbolic gesture pattern.

The system does **not** require manual typing, dropdown selection, QR codes, or fixed gesture sequences.

## Important note about identity recognition

This implementation uses **anonymous appearance-based re-identification**, not biometric identification. It assigns temporary labels such as `Person 1` or `Person 2` based on general visual appearance during the session.

## Installation

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

## Controls

| Key | Action |
|---|---|
| `q` | Quit |
| `s` | Save screenshot |
| `r` | Reset current CSV log and in-memory person profiles |
| `m` | Toggle 67 meme mode |

## Evidence screenshots

Take at least 5 screenshots:

1. Webcam detecting a hand and finger count.
2. Webcam showing gesture classification.
3. Webcam showing left/right hand detection.
4. Dashboard panel showing indicators.
5. CSV log opened in Excel/Google Sheets or generated `gesture_log.csv`.
6. Optional: Returning participant detected as the same anonymous person.

## Main indicators

- Total detections.
- Most common gesture.
- Most common finger count.
- Thumbs-up rate.
- Left-hand and right-hand proportions.
- Detections by person.
- Returning participant count.
- Gesture distribution.
- Trend by minute.
